from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from login import views
from products.models import Product


# Create your views here.
def home_view(request, *args, **kwargs):
    return render(request, "home.html", {})

def add_order(request, *args, **kwargs):
    return render(request, "add_order.html", {})


def item_relation_view(request):
    obj = Product.objects.get(id=1)

    context = {
        'Number': obj.idNum,
        'Name': obj.name,
        'Type': obj.itemType
    }

    return render(request, "item_relation.html", context)

def price_adjustment_view(request, *args, **kwargs):
    # return HttpResponse("<h1>Material Price</h1>")
    return render(request, "price_adjustment.html", {})
