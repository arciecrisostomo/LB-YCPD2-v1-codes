from django.apps import AppConfig


class RawConfig(AppConfig):
    name = 'raw'


# class TestConfig(AppConfig):
#     name = 'test'
