from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout


# Create your views here.
def new_raw_view(request, *args, **kwargs):
    # return HttpResponse("<h1>Set Raw Materials</h1>")
    return render(request, "add_raw.html", {})


def edit_raw_view(request, *args, **kwargs):
    # return HttpResponse("<h1>Product Details</h1>")
    return render(request, "edit_raw.html", {})


def delete_raw_view(request, *args, **kwargs):
    # return HttpResponse("<h1>Delete Raw Material</h1>")
    return render(request, "delete_raw.html", {})
