from django.contrib import admin
from .models import Raw

# Register your models here.
admin.site.register(Raw)
# admin.site.register(Test)