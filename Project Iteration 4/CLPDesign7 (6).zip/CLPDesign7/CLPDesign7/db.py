import psycopg2

# connect to the db
con = psycopg2.connect(
     host="localhost",
     database="sampleDatabase",
     user="postgres",
     password="clp"
)

# con = psycopg2.connect(
#      host="localhost",
#      database="accounts",
#      user="clp",
#      password="clpclpclp"
# )

## will be replaced
# cursor
cur = con.cursor()

table = '''create table ProductsToSell(
   ReferenceNumber bigint unique not null,
   Item varchar(50) not null,
   Type varchar(50) not null,
   SellingPrice float not null,
   RawMaterialPrice float not null,
   IncomePerOrder float not null,
   Notes char null 
)'''

cur.execute(table)

# close the cursor
cur.close()

con.commit()

# close the db
con.close()
