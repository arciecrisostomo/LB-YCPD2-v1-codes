from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout


# Create your views here.
def register_page(request):
    # default: username, password, and password confirmation
    form = UserCreationForm()

    # django's login form is returned
    if request.method == 'POST':

        # form is rendered
        form = UserCreationForm(request.POST)

        # form validation
        if form.is_valid():
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, user + ' account successfully created')

            return redirect('register_details')

    context = {'form': form}
    return render(request, 'register.html', context)


def register_details_page(request):
    form = UserCreationForm()

    # ! what does this do !
    # if request.method == 'POST':
    #     form = UserCreationForm(request.POST)

    context = {'form': form}
    return render(request, 'register_details.html', context)


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        # if information is correctly entered
        if user is not None:

            # process login method that was imported
            login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'Username or password is incorrect')

    context = {}

    # return user to login page
    return render(request, "login.html", context)


def logoutUser(request):
    # process logout method that was imported
    logout(request)
    return redirect('login')
