from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from products.models import Product


# Create your views here.
def new_product_view(request):
    if request.method == 'POST':
        if request.POST.get('name') and request.POST.get('idNum') and request.POST.get('itemType') and request.POST.get(
                'sellPrice') and request.POST.get('rawCost') and request.POST.get('profit') and request.POST.get('tax'):
            saverecord = Product()
            saverecord.name = request.POST.get('name')
            saverecord.idNum = request.POST.get('idNum')
            saverecord.itemType = request.POST.get('itemType')
            saverecord.sellPrice = request.POST.get('sellPrice')
            saverecord.rawCost = request.POST.get('rawCost')
            saverecord.profit = request.POST.get('profit')
            saverecord.tax = request.POST.get('tax')
            saverecord.save()
            messages.success(request, 'record saved successfully')
            return render(request, 'item_relation.html')


    else:
        return render(request, 'add_product.html')


def edit_product_view(request, *args, **kwargs):
    # return HttpResponse("<h1>Edit Product Details</h1>")
    return render(request, "edit_product.html", {})


def delete_product_view(request, *args, **kwargs):
    # return HttpResponse("<h1>Delete Existing Product</h1>")
    return render(request, "delete_product.html", {})
