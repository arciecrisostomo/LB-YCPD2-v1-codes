from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.
def home_view(*args, **kwargs):
    return HttpResponse("<h1><a href='http://127.0.0.1:8000/login/'>Ohaiyo!</a></h1>")


def login_view(*args, **kwargs):
    return HttpResponse("<h1>Login</h1>")


def register_view(*args, **kwargs):
    return HttpResponse("<h1>Registration</h1>")


def new_product_view(*args, **kwargs):
    return HttpResponse("<h1>Add New Product</h1>")


def new_raw_view(*args, **kwargs):
    return HttpResponse("<h1>Set Raw Materials</h1>")


def item_relation_view(*args, **kwargs):
    return HttpResponse("<h1>Product Details</h1>")


def price_adjustment_view(*args, **kwargs):
    return HttpResponse("<h1>Material Price</h1>")


def edit_product_view(*args, **kwargs):
    return HttpResponse("<h1>Edit Product Details</h1>")


def edit_raw_view(*args, **kwargs):
    return HttpResponse("<h1>Product Details</h1>")


def delete_product_view(*args, **kwargs):
    return HttpResponse("<h1>Delete Existing Product</h1>")


def delete_raw_view(*args, **kwargs):
    return HttpResponse("<h1>Delete Raw Material</h1>")


def sold_products_view(*args, **kwargs):
    return HttpResponse("<h1>Products Sold Database</h1>")


def existing_products_view(*args, **kwargs):
    return HttpResponse("<h1>Products Database</h1>")


def raw_database_view(*args, **kwargs):
    return HttpResponse("<h1>Raw Materials Database</h1>")
