from django.apps import AppConfig


class RawConfig(AppConfig):
    name = 'raw'
