"""CLPDesign4 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

from pages.views import (home_view, login_view, register_view, new_product_view, new_raw_view, item_relation_view,
                         price_adjustment_view, edit_product_view, edit_raw_view, delete_product_view, delete_raw_view,
                         sold_products_view, existing_products_view, raw_database_view)

urlpatterns = [
    path('admin/', admin.site.urls),

    path('home/', home_view, name='home'),
    path('login/', login_view, name='login'),
    path('register/', register_view, name='register'),
    path('new_product/', new_product_view, name='new_product'),
    path('new_raw/', new_raw_view, name='new_raw'),
    path('item_relation/', item_relation_view, name='item_relation'),
    path('price_adjustment/', price_adjustment_view, name='price_adjustment'),
    path('edit_product/', edit_product_view, name='edit_product'),
    path('edit_raw/', edit_raw_view, name='edit_raw'),
    path('delete_product', delete_product_view, name='delete_product'),
    path('delete_raw/', delete_raw_view, name='delete_raw'),
    path('sold_database/', sold_products_view, name='sold_database'),
    path('products_database/', existing_products_view, name='products_database'),
    path('raw_database/', raw_database_view, name='raw_database'),

]
