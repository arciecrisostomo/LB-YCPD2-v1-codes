from django.apps import AppConfig


class SmallbusinessappConfig(AppConfig):
    name = 'SmallBusinessApp'
